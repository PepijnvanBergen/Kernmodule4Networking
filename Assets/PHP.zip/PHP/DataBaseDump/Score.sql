-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 09 aug 2021 om 19:55
-- Serverversie: 10.2.32-MariaDB
-- PHP-versie: 5.5.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pepijnvanbergen`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `Score`
--

CREATE TABLE `Score` (
  `id` int(11) NOT NULL,
  `pId` int(11) NOT NULL,
  `serverID` int(32) NOT NULL,
  `score` int(11) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Gegevens worden geëxporteerd voor tabel `Score`
--

INSERT INTO `Score` (`id`, `pId`, `serverID`, `score`, `date`) VALUES
(10, 5, 1, 8, '2021-08-08 16:06:52'),
(11, 3, 1, 3, '2021-08-09 13:01:23'),
(12, 3, 2, 3, '2021-08-09 14:06:22'),
(13, 3, 2, 3, '2021-08-09 14:10:16'),
(14, 3, 2, 3, '2021-08-09 14:10:54'),
(15, 3, 2, 3, '2021-08-09 14:11:14'),
(16, 3, 2, 3, '2021-08-09 16:11:59'),
(17, 3, 2, 4, '2021-08-09 20:30:27'),
(18, 3, 2, 7, '2021-08-09 20:52:13'),
(19, 1, 2, 4, '2021-08-09 20:52:53'),
(20, 1, 2, 5, '2021-08-09 20:53:19'),
(21, 1, 2, 6, '2021-08-09 20:53:31');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `Score`
--
ALTER TABLE `Score`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `Score`
--
ALTER TABLE `Score`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
