<?php 
    include 'PhPConnect.php';

    // Show top 5 winners
    //$query = "SELECT s.score, s.date, u.naam FROM scores s LEFT JOIN users u ON (s.user_id = u.id) ORDER BY s.date DESC LIMIT 5";
    $query = "SELECT pId, score FROM Score ORDER BY score DESC LIMIT 5";
    if (!($result = $mysqli->query($query)))
    {
        showerror($mysqli->errno,$mysqli->error);
        echo("{\"result\":\"0\"}");
    }
    else
    {
        $row = $result->fetch_assoc();
        do 
        {
            echo("<br>");
            echo json_encode($row);
        } while ($row = $result->fetch_assoc());
    }

    // Show top 5 winners last month
    $query = "SELECT pId, score FROM Score WHERE YEAR(date) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH) AND MONTH(date) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH) ORDER BY score DESC LIMIT 5";
    if (!($result = $mysqli->query($query)))
    {
        showerror($mysqli->errno,$mysqli->error);
        echo("{\"result\":\"0\"}");
        return;
    }
    else
    {
        $row = $result->fetch_assoc();
        do 
        {
            echo("<br>");
            echo json_encode($row);
        } while ($row = $result->fetch_assoc());
    }

    // Show how much games are played last month (today but last month)
    $query = "SELECT pId, score FROM Score WHERE YEAR(date) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH) AND MONTH(date) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH)";
    if (!($result = $mysqli->query($query)))
    {
        showerror($mysqli->errno,$mysqli->error);
        echo("{\"result\":\"0\"}");
        return;
    }
    $rowAmount = mysqli_num_rows($result);
    echo("<br>");
    echo("{\"times_played_last_month\":\"" . $rowAmount . "\"}");
?>