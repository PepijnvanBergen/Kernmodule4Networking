<?php
include 'PhPConnect.php';
//INSERT INTO tabelnaam (fieldnaam1,fieldnaam3,fieldnaam2) VALUES (waarde1,waarde3,waarde2)
//UPDATE table_name SET column1=value, column2=value2,... WHERE some_column=some_value

//Error (You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '@gmail, 1234)' at line 1) 1064
$naam = $_GET["naam"];
$email = $_GET["email"];
$wachtwoord = $_GET["wachtwoord"];
$query = "INSERT INTO Spelers (id,naam,email, wachtwoord) VALUES (NULL,'$naam','$email','$wachtwoord')";
if(!($result = $mysqli->query($query)))
    {
        showerror($mysqli->errno, $mysqli->error);
    } 
if ($mysqli->query($query) === TRUE) 
    {
        $last_id = $mysqli->insert_id;
        echo json_encode($last_id);
    } else 
    {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
?>