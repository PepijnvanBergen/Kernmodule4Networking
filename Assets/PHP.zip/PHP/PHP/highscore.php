<?php
include 'PhPConnect.php';
$scores = "Score";
$spelers = "Spelers";
    
$query = "SELECT s.pId, s.score, s.date FROM Score s LEFT JOIN Spelers p ON(s.pId = p.id) ORDER BY s.date desc LIMIT 5";

//$query = "SELECT COUNT(Score) FROM Spelers WHERE pId = 1 AND date BETWEEN '2021/04/27' AND '2021/04/27'"; //Hier loeren naar wat de afgelopen zeven dagen zijn.
$Result = $mysqli->query($query);
if(!($result = $mysqli->query($query)))
{
    showerror($mysqli->errno, $mysqli->error);
}
$row = $result->fetch_assoc();

do
{
    echo("<br>");
    echo json_encode($row);
    
}while($row = $result->fetch_assoc());

foreach($scores->query("select count(*) as cnt,sum(score) as tot from eval where empid=$empid") as $data)
{
   $avg=($data['cnt']/$data['tot'])*100;
    echo $avg;
}
 
?>