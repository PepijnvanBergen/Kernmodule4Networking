Dit zijn de login gegevens die gebruikt kunnen worden om de game te spelen.
Server:
ID = 2
Wachtwoord = wachtwoordwachtwoord2

User:
ID = 1
wachtwoord = PepijnPepijn
User:
ID = 3
wachtwoord = DonDon