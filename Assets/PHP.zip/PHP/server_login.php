<?php
include 'PhPConnect.php';
session_id("playTheGame123");
session_start();
$sessionID = session_id();

$id = $_GET["id"];
$pw = $_GET["pw"];
//validaten
//$query = "SELECT serverID FROM Servers WHERE serverID = '", $id , "' and wachtwoord = '$pw'";
$query = "SELECT serverID FROM Servers WHERE wachtwoord = '" . $pw . "'";

if(!($result = $mysqli->query($query)))
{
    showerror($mysqli->errno, $mysqli->error);
}
$row = $result->fetch_assoc();

if(mysqli_num_rows($result) == 1)
{
    //session_destroy();
    if($row ["serverID"] == $id)
    $_SESSION["serverID"] = $id;
    //echo json_encode($id). "<br>";
    echo json_encode($sessionID);
}else{
    echo "wrong ID or Password" . "<br>";
    echo "0";
}
?>