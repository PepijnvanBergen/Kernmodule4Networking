<?php
session_start();
include 'PhPConnect.php';
//INSERT INTO tabelnaam (fieldnaam1,fieldnaam3,fieldnaam2) VALUES (waarde1,waarde3,waarde2)
    
if (isset($_GET['PHPSESSID']))
{ //staat de sessie id in de url?
    $sid=htmlspecialchars($_GET['PHPSESSID']); //sessie id uit url sanitizen
        //echo $sid;
    session_id($sid); //sessie id voor deze sessie instellen naar wat uit url kwam
}

//$pId = $_GET["pId"];//Hetzelfde toepassen met de rest van de score values.
$score = $_GET["score"];
$serverID = $_SESSION["serverID"];
$pId = $_SESSION["id"];

//$query = "INSERT INTO Score (id,pId,isWon, score) VALUES (NULL,$pId,$isWon,$score)";
$query = "INSERT INTO Score (id,pId,serverID, score) VALUES (NULL,'$pId','$serverID','$score')";
session_destroy();
if(!($result = $mysqli->query($query)))
{
    showerror($mysqli->errno, $mysqli->error);
    echo "0";
}
else
{
    echo "1";
}
//}
?>