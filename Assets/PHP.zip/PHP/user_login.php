<?php
include 'PhPConnect.php';
session_start();

if (isset($_GET['PHPSESSID']))
{ //staat de sessie id in de url?
    $sid=htmlspecialchars($_GET['PHPSESSID']); //sessie id uit url sanitizen
        //echo $sid;
    session_id($sid); //sessie id voor deze sessie instellen naar wat uit url kwam
}

$id = $_GET["id"];
$pw = $_GET["pw"];
//validaten

//$query = "SELECT id FROM Spelers WHERE naam = '" . $username . "' and wachtwoord = '" . $pw . "'";
$query = "SELECT id FROM Spelers WHERE wachtwoord = '" . $pw . "'";

if(!($result = $mysqli->query($query)))
{
    showerror($mysqli->errno, $mysqli->error);
}
$row = $result->fetch_assoc();

if(mysqli_num_rows($result) == 1)
    {//Check if row username == username from url
    if($row ["id"] == $id)
        $_SESSION["id"] = $id;
        echo json_encode($id) . "<br>";
        //echo json_encode($sessionID);
    }    
    else
    {
        echo "wrong ID or Password" . "<br>";
        echo "0";
    }
?>